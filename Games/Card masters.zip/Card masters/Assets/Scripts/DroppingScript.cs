﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class DroppingScript : MonoBehaviour,IDropHandler {
	public int cards;
	private GameObject[] cardsInside;
	// Use this for initialization
	void Start () {
	
	}

	#region IDropHandler implementation

	public void OnDrop (PointerEventData eventData)
	{
		if (GameController.p1CardsActive < 2 && eventData.pointerDrag.GetComponent <CardBehavior>().active != true && this.name=="PlayArea1") {
			eventData.pointerDrag.transform.SetParent (this.transform);
			eventData.pointerDrag.GetComponent <CardBehavior>().setActive ();
			eventData.pointerDrag.GetComponent <CardBehavior> ().canAttack = false;
			cards++;
			GameController.hand1Cards--;
			GameController.p1CardsActive++;
			GameController.p1Attacks++;

		}
	}

	#endregion
	
	// Update is called once per frame
	void Update () {
		
	}

	public void updateCards(){
		cardsInside = new GameObject[transform.childCount];
		for(int i=0;i<transform.childCount;i++){
			cardsInside [i] = transform.GetChild (i).gameObject;
			cardsInside [i].GetComponent <CardBehavior> ().canAttack = true;
			cardsInside [i].GetComponent <CardBehavior> ().thisAttacked = false;
		}
	}
}

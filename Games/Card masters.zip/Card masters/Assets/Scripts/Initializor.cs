﻿using UnityEngine;
using System.Collections;

public class Initializor : MonoBehaviour {
	public Texture2D cursorTexture;
	// Use this for initialization
	void Start () {
		
		Cursor.SetCursor(cursorTexture,new Vector2(10,10),CursorMode.Auto);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

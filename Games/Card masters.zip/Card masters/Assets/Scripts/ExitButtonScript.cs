﻿using UnityEngine;
using System.Collections;
using System;


public class ExitButtonScript : MonoBehaviour {
	
	public void ClickExit () {
		Debug.Log ("Exited");
		Application.Quit();

	}
}

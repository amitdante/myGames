﻿using UnityEngine;
using System.Collections;

public class Deck : MonoBehaviour {
	public GameObject hand1;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Debug.Log (GameController.hand1Cards);
	}
	public void onClicked(){
		if (GameController.hand1Cards < 3 && GameController.p1TotalDrawn<=10 && hand1.GetComponent <addCards>().drawn==false && GameController.turn==1 && GameController.firstChance==false) {
			hand1.GetComponent<addCards> ().drawCard ();
			GameController.p1TotalDrawn++;
			hand1.GetComponent <addCards> ().drawn = true;

		}

	}
}

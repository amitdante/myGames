﻿using UnityEngine;
using System.Collections;

public class EndTurn : MonoBehaviour {
	public GameObject gameController;
	private GameObject hand1;
	private GameObject playArea1;
	// Use this for initialization

	void Awake(){
		gameController = GameObject.Find ("GameController");

	}
	void Start () {
		hand1 = GameObject.Find ("Hand1");
		playArea1 = GameObject.Find ("PlayArea1");
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public void OnClicked(){
		GameController.firstChance = false;
		GameController.turn = 2;
		gameController.GetComponent <GameController>().aiChance ();
		hand1.GetComponent <addCards>().drawn=false;
		playArea1.GetComponent <DroppingScript>().updateCards ();
	}
}

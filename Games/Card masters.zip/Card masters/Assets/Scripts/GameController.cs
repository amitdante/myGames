﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameController : MonoBehaviour {
	public GameObject playArea1;
	public GameObject playArea2;
	public GameObject canvas;
	public GameObject endTurn;
	public static int p1CardsActive;
	public static int p2CardsActive;
	public static int turn;
	public static int hand1Cards;
	public static int hand2Cards;
	public bool p1Attacking;
	public int damage;
	public Texture2D cursorTexture2;
	public GameObject hand1;
	public GameObject hand2;
	public GameObject sword;
	GameObject cardToMove;
	GameObject cardAttacking;
	public static int p1Attacks;
	public static int p1TotalDrawn;
	public static int p2TotalDrawn;
	public static bool firstChance;
	public static int p2HP;
	public static int p1HP;
	private GameObject p1WinText;
	private GameObject p2WinText;
	private GameObject replayButton;



	void Awake(){
		p1CardsActive = 0;
		p2CardsActive = 0;
		hand1Cards = 0;
		hand2Cards = 0;
	}
	// Use this for initialization
	void Start () {
		
		p1Attacking = false;
		turn = 1;
		p1Attacks = 0;
		p1TotalDrawn = 0;
		p2TotalDrawn = 0;
		firstChance = true;
		p2HP = 100;
		p1HP = 100;
	}
	
	// Update is called once per frame
	void Update () {
		
		Debug.Log (hand2Cards);
	}
	public void attackFinished(int nextTurn){
		
		Cursor.SetCursor (cursorTexture2, new Vector2 (10, 10), CursorMode.Auto);
		if(p1Attacks!=0){
			p1Attacking = false;
		}
		if(p1Attacks==0){
			turn = nextTurn;
		}
		if(turn==2){
			p1Attacking = false;

		}
		if(nextTurn==1){
			turn = 1;
		}

	}
	public void aiChance(){
		if (p2TotalDrawn <= 10 && hand2Cards<3) {
			hand2.GetComponent <addCards> ().drawCard ();
		}
		
		if (p2CardsActive<2){
			cardToMove = hand2.transform.GetChild (Random.Range (0,2)).gameObject;
			cardToMove.transform.SetParent (playArea2.transform);
			//cardToMove.transform.localPosition = new Vector3 (0, 0, 0);
			cardToMove.GetComponent <RectTransform>().localPosition=new Vector3 (0, 0, 0);
			Destroy (cardToMove.transform.GetChild (2).gameObject);
			p2CardsActive++;
			hand2Cards--;
		}
		if(p2CardsActive>0){
			if (playArea2.transform.childCount == 1) {
				cardAttacking = playArea2.transform.GetChild (0).gameObject;
			}else if(playArea2.transform.childCount == 2){
				cardAttacking = playArea2.transform.GetChild (Random.Range (0,1)).gameObject;
			}
			sword = (GameObject)Instantiate (Resources.Load ("sword"));
			sword.transform.SetParent (cardAttacking.transform);
			sword.transform.localPosition = new Vector2 (0, 0);
			if (p1CardsActive != 0) {
				StartCoroutine ("aiAttacking", cardAttacking);
			}else if(p1CardsActive==0){
				damage = cardAttacking.GetComponent <CardInfo> ().attack;
				attackP1 ();
				StartCoroutine ("attackEnd");
			}


		}
	}
	IEnumerator aiAttacking(GameObject cardAttacking){
		Vector3 startPosition = cardAttacking.transform.localPosition;

		int i=0;
		GameObject cardToBeAttacked = playArea1.transform.GetChild (0).gameObject;
		yield return new WaitForSeconds (1.0f);
		while (cardAttacking.transform.position.y >= cardToBeAttacked.transform.position.y) {
			cardAttacking.transform.position = Vector2.Lerp (new Vector2 (cardAttacking.transform.position.x, cardAttacking.transform.position.y), new Vector2 (cardToBeAttacked.transform.position.x, cardToBeAttacked.transform.position.y), 0.10f);
			i++;
			if(i==150){
				cardAttacking.transform.localPosition = new Vector3 (100, startPosition.y, 0f);
				cardAttacking.transform.SetParent (this.transform);
				cardAttacking.transform.SetParent (playArea2.transform);


				damage = cardAttacking.GetComponent <CardInfo>().attack;
				p1Attacking = false;

				cardToBeAttacked.GetComponent <CardBehavior>().defensePower = cardToBeAttacked.GetComponent <CardInfo> ().defence;

				cardToBeAttacked.GetComponent <CardBehavior> ().defensePower -= damage;

				cardToBeAttacked.GetComponent <CardInfo>().updateStats(cardToBeAttacked.GetComponent <CardBehavior> ().defensePower);
				attackFinished (1);
				Destroy (sword);
				StopCoroutine ("aiAttacking");
			}

			yield return null;
		}

	}

	public void attackP2(){
		p2HP -= damage;
		if(p2HP<=0){
			p1WinText = (GameObject)Instantiate (Resources.Load ("P1WinText"));
			p1WinText.transform.SetParent (canvas.transform);
			replayButton = (GameObject)Instantiate (Resources.Load ("ReplayButton"));
			replayButton.transform.SetParent (canvas.transform);
		}
	}
	public void attackP1(){
		p1HP -= damage;
		if(p1HP<=0){
			p2WinText = (GameObject)Instantiate (Resources.Load ("P2WinText"));
			p2WinText.transform.SetParent (canvas.transform);
			p2WinText.transform.localPosition = new Vector2 (0, 0);
			replayButton = (GameObject)Instantiate (Resources.Load ("ReplayButton"));
			replayButton.transform.SetParent (canvas.transform);
			replayButton.transform.localPosition = new Vector2 (0, -200);
			Destroy (endTurn);
		}

	}

	IEnumerator attackEnd(){
		yield return new WaitForSeconds (1.0f);
		Destroy (sword);
		StopCoroutine ("attackEnd");
	}
}

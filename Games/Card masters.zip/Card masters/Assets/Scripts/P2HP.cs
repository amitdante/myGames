﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class P2HP : MonoBehaviour {
	private Text hp;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		this.GetComponent <Text> ().text = GameController.p2HP.ToString ();
	}

}

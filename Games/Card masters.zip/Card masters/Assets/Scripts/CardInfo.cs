﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;



public class CardInfo : MonoBehaviour {
	public int attack;
	public int defence=55;
	Text attackText;
	Text defenceText;
	GameObject gameController;

	void Awake(){
		gameController = GameObject.Find ("GameController");

	}


	// Use this for initialization
	void Start () {
		attack = Random.Range (50, 100);
		defence = Random.Range (50, 100);
		attackText = gameObject.transform.GetChild (0).transform.GetComponent<Text>();
		attackText.text = attack.ToString ();
		defenceText = gameObject.transform.GetChild (1).transform.GetComponent<Text>();
		defenceText.text = defence.ToString ();
	}
	
	// Update is called once per frame
	void Update () {

	}
	public void updateStats(int defensePower){
		defence = defensePower;
		defenceText.text = defence.ToString ();
		if (defence <= 0 && GameController.turn==1){
			GameController.p2CardsActive--;
			Destroy (gameObject);

		}else if(defence <= 0 && GameController.turn==2){
			GameController.p1CardsActive--;
			Destroy (gameObject);
		}

	}
}

﻿using UnityEngine;
using System.Collections;

public class addCards : MonoBehaviour {
	private GameObject card1;
	private GameObject card2;
	private GameObject card3;
	private GameObject cardBack;
	private GameObject card;

	public bool drawn;
	// Use this for initialization
	void Start () {
		
		drawn = false;
		card1 = (GameObject)Instantiate (Resources.Load ("CardFront"));
		card1.transform.SetParent (this.transform);


		card2 = (GameObject)Instantiate (Resources.Load ("CardFront"));
		card2.transform.SetParent (this.transform);

		card3 = (GameObject)Instantiate (Resources.Load ("CardFront"));
		card3.transform.SetParent (this.transform);

		if(this.name=="Hand1"){
			card1.GetComponent <CardBehavior>().cardOwner = 1;
			card2.GetComponent <CardBehavior>().cardOwner = 1;
			card3.GetComponent <CardBehavior>().cardOwner = 1;
			GameController.hand1Cards = 3;


		}else{
			card1.GetComponent <CardBehavior>().cardOwner = 2;
			cardBack = (GameObject)Instantiate (Resources.Load ("CardBack"));
			cardBack.transform.SetParent (card1.transform);
			cardBack.transform.localPosition = new Vector2 (0, 0);
			card2.GetComponent <CardBehavior>().cardOwner = 2;
			cardBack = (GameObject)Instantiate (Resources.Load ("CardBack"));
			cardBack.transform.SetParent (card2.transform);
			cardBack.transform.localPosition = new Vector2 (0, 0);
			card3.GetComponent <CardBehavior>().cardOwner = 2;
			cardBack = (GameObject)Instantiate (Resources.Load ("CardBack"));
			cardBack.transform.SetParent (card3.transform);
			cardBack.transform.localPosition = new Vector2 (0, 0);
			GameController.hand2Cards = 3;
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public void drawCard(){
		card = (GameObject)Instantiate (Resources.Load ("CardFront"));
		card.transform.SetParent (this.transform);
		if (this.name == "Hand1") {
			GameController.hand1Cards++;
		}else if(this.name=="Hand2"){
			GameController.hand2Cards++;
			cardBack = (GameObject)Instantiate (Resources.Load ("CardBack"));
			cardBack.transform.SetParent (card.transform);
			cardBack.transform.localPosition = new Vector2 (0, 0);

		}

	}


}

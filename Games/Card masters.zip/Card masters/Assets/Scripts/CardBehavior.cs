﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;


public class CardBehavior : MonoBehaviour,IBeginDragHandler,IEndDragHandler,IDragHandler {



	GameObject card;
	public GameObject playArea;
	Vector2 originalPosition;
	public bool active = false;
	GameObject sword;
	public Texture2D cursorTexture;
	GameObject gameController;
	int state = 0;
	public int cardOwner;
	public int attackPower;
	public int defensePower;
	public bool thisAttacked;
	public bool canAttack;


	void Awake(){
		gameController = GameObject.Find ("GameController");

	}

	void start (){
		card = gameObject;
		thisAttacked = false;
		canAttack = false;
	}

	#region IBeginDragHandler implementation

	public void OnBeginDrag (PointerEventData eventData)
	{
		if (this.active != true && cardOwner==1) {
			originalPosition = new Vector2 (transform.localPosition.x, transform.localPosition.y);
			this.transform.position = eventData.position;
			GetComponent<CanvasGroup> ().blocksRaycasts = false;
		}


	}

	#endregion

	#region IDragHandler implementation

	public void OnDrag (PointerEventData eventData)
	{
		if (this.active != true && cardOwner==1) {
			this.transform.position = eventData.position;
		}

	}

	#endregion

	#region IEndDragHandler implementation

	public void OnEndDrag (PointerEventData eventData)
	{
		if (cardOwner == 1) {
			GetComponent<CanvasGroup> ().blocksRaycasts = true;
			if (this.active != true) {
			
				if (playArea.GetComponent<DroppingScript> ().cards == 0) {
					this.transform.localPosition = originalPosition;
				}
			}
		}
	}

	#endregion

	

	void Update()
	{
		if(active!=true){
			
			if(this.transform.parent.name == "Hand1"){
				cardOwner = 1;

			}
			if(this.transform.parent.name == "Hand2"){
				cardOwner = 2;

			}
		}
	}
	public void setActive(){
		active = true;

	}
	public void attackFunction(){
		if (this.active == true && GameController.firstChance==false && gameController.GetComponent <GameController> ().p1Attacking == false&& cardOwner==1 && GameController.turn ==1 && thisAttacked==false && GameController.p2CardsActive == 0&& canAttack==true) {
			Debug.Log ("entered");
			sword = (GameObject)Instantiate (Resources.Load ("sword"));
			sword.transform.SetParent (gameObject.transform);
			sword.transform.localPosition = new Vector2 (0, 0);
			Cursor.SetCursor (cursorTexture, new Vector2 (10, 10), CursorMode.Auto);
			state = 1;
			attackPower = this.GetComponent <CardInfo> ().attack;
			gameController.GetComponent <GameController> ().p1Attacking = true;
			gameController.GetComponent <GameController> ().damage = attackPower;
			GameController.p1Attacks--;
			thisAttacked = true;
			gameController.GetComponent <GameController>().attackP2 ();
			StartCoroutine ("attackEnd");

		}
		
		else if (this.active == true && GameController.firstChance==false && gameController.GetComponent <GameController> ().p1Attacking == false&& cardOwner==1 && GameController.turn ==1 && thisAttacked==false && canAttack==true) {
			sword = (GameObject)Instantiate (Resources.Load ("sword"));
			sword.transform.SetParent (gameObject.transform);
			sword.transform.localPosition = new Vector2 (0, 0);
			Cursor.SetCursor (cursorTexture, new Vector2 (10, 10), CursorMode.Auto);
			state = 1;
			attackPower = this.GetComponent <CardInfo> ().attack;
			gameController.GetComponent <GameController> ().p1Attacking = true;
			gameController.GetComponent <GameController> ().damage = attackPower;
			GameController.p1Attacks--;
			thisAttacked = true;
			StartCoroutine ("attackEnd");

		}else if(cardOwner==2 && gameController.GetComponent <GameController> ().p1Attacking == true){
			defensePower = this.GetComponent <CardInfo> ().defence;

			defensePower -= gameController.GetComponent <GameController> ().damage;

			this.GetComponent <CardInfo>().updateStats(defensePower);

			gameController.GetComponent <GameController>().attackFinished(2);


		}
	}
	IEnumerator attackEnd(){
		yield return new WaitForSeconds (2.0f);
		Destroy (sword);
		StopCoroutine ("attackEnd");
	}

}

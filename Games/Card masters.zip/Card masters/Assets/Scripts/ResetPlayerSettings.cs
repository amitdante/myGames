﻿using UnityEngine;
using System.Collections;

public class ResetPlayerSettings : MonoBehaviour {

	// Use this for initialization
	void Start () {
		PlayerPrefs.DeleteAll ();
		Application.Quit ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

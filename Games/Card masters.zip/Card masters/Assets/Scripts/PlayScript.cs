﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class PlayScript : MonoBehaviour {
	public Scene main;

	void Start(){
		main = SceneManager.GetSceneAt (SceneManager.sceneCount-1);
		Debug.Log (main.name);
	}
	public void PlayClick(){
		SceneManager.LoadScene ("Main");
		Debug.Log(SceneManager.GetActiveScene ().name + "Is the current scene");
	}
}
